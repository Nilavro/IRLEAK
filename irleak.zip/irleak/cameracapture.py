from picamera import PiCamera
from time import sleep

camera = PiCamera()

for i in range (0,10):
	sleep(2)
	name = '/home/pi/raspberrypi_ir/cameraimages/pic' + str(i) + '.jpg'
	camera.capture(name)
