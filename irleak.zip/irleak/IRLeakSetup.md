# IRLeak Setup

## Image the SDCard

1. Download the most recent Raspbian Lite Image
    * `wget -c https://downloads.raspberrypi.org/raspbian_lite_latest`
2. Unzip the image
    * `unzip *-raspbian-jessie-lite.zip`
3. Insert the SDCard into the reader
4. Find the device name of the SDCard
    * run `fdisk -l | less` and find the name of the device
    * on Ubuntu, this is probably `/dev/mmcblk0`
5. Write the image to the SDCard
    * `sudo ddrescue -D --force *-raspbian-jessie-lite.img /dev/mmcblk0`

## Setup the system
0. Ensure network connection
    * Follow the guide here: `https://www.raspberrypi.org/documentation/configuration/wireless/wireless-cli.md`
1. Install updates
    * `sudo apt update; sudo apt -y upgrade; sudo apt -y full-upgrade; sudo apt-get -y autoremove; sudo apt-get -y autoclean`
2. Install software
    * `sudo apt -y install openssh-server tmux autossh python3 python3-gpiozero python3-smbus`
    * `sudo apt -y install python3-pigpio python3-picamera python3-sh git rsync python-smbus python-gpiozero` 
    * `sudo apt -y install python-pigpio python-picamera python-sh`
3. Configure the RasPi
    * `sudo raspi-config`
    * Localization Options 
        * --> Change Locale
            * generate the en.US-UTF8 locale
            * set the en.US-UTF8 locale to default
        * --> Change Timezone --> US --> Eastern
        * --> Change Keyboard Layout --> Generic 104 Key, Generic US
        * --> Change Wi-Fi Country --> US
    * Expand Filesystem
    * Boot Options 
        * --> disable wait for network
        * --> Desktop/CLI --> Console autologin
    * Interfacing Options
        * --> Camera --> Enable
        * --> SSH --> Enable
        * --> I2C --> Enable
    * Advanced Options --> Memory Split --> 16
4. Reboot
5. Establish a reverse ssh tunnel so you can use a real computer to do the rest of this
    * `autossh -v -nNT -R 110##:localhost:22 yourname@eclipse.umbc.edu`
6. Log in from your real computer
    * `ssh -J eclipse.umbc.edu -p 110## pi@localhost`
7. Generate a SSH key on the Pi
    * `ssh-keygen`
    * Leave password blank
8. Copy the SSH key to eclipse
    * `ssh-copy-id yourname@eclipse.umbc.edu`
9. Add your SSH public key to Gogs on Eclipse
10. Clone the code to the Pi
    * `git clone git@eclipse.umbc.edu:yourname/irleak.git`
11. Automatically create the reverse SSH tunnel
    * `sudo cp /home/pi/irleak/starttunnel.service /lib/systemd/system/`
    * `sudo systemctl daemon-reload`
    * `sudo systemctl enable starttunnel.service`
12. Automatically stop the motor on boot
    * `sudo cp /home/pi/irleak/stop-motor.service /lib/systemd/system/`
    * `sudo systemctl daemon-reload`
    * `sudo systemctl enable stop-motor.service`
13. Automatically start `pigpiod` with the crontab
    * Run `sudo crontab -e` and add the line
    * `@reboot /usr/bin/pigpiod`
14. Automatically start the camera and the upload on a schedule
    * Run `crontab -e` and add two lines
    * `0,30 * * * * /home/pi/irleak/work.py`
        * This causes the camera to take a set of images on the 0th and 30th minute of every hour.
    * `15,45 * * * * /home/pi/irleak/do_sync.sh`
        * This causes the device to attempt to sync its images on the 15th and 45th minute of every hour.








