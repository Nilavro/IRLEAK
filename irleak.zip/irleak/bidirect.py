import pigpio
from picamera import PiCamera
import RPi.GPIO as GPIO
import time


#pins = {'b':25, 'p':22, 'y':24, 'o':23}
pins = { 'o':22,
         'y':23,
         'p':24,
         'b':25 }


def stater(s):
    i = 0
    while True:
        yield(s[i])
        i += 1
        i %= len(s)


def step(state):
    set_pins(pins, next(state))
    time.sleep(.02)


def set_pins(ps, setting):
    GPIO.output(ps['p'], setting[0])
    GPIO.output(ps['o'], setting[1])
    GPIO.output(ps['y'], setting[2])
    GPIO.output(ps['b'], setting[3])


def traverse(state):
    acc = 0
    for i in range(100):
        acc += 1
        step(state)
    while not GPIO.input(8):
        acc += 1
        step(state)
    return acc


revst = stater(list(reversed([(1,0,1,0), (0,1,1,0), (0,1,0,1), (1,0,0,1)])))
forst = stater([(1,0,1,0), (0,1,1,0), (0,1,0,1), (1,0,0,1)])


def forward():
    return traverse(forst)


def backward():
    return traverse(revst)


GPIO.setmode(GPIO.BCM)
_ = [GPIO.setup(p, GPIO.OUT) for p in pins.values()]
GPIO.setup(8, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

camera = PiCamera()

pi = pigpio.pi()


