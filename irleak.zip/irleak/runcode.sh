python work.py
rmdir -r cameraimages
mkdir camera images
rmdir -r ircapture
mkdir ircapture 
python work.py
