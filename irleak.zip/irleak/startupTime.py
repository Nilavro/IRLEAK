#!/usr/bin/env python3
import time

now = time.time()

with open('/home/pi/.boottime', 'w') as FILE:
    FILE.write(str(int(time.time()*1000)))
