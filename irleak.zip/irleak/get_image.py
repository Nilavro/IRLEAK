#!/usr/bin/env python
import smbus
import time
import pigpio
from picamera import PiCamera
import RPi.GPIO as GPIO
import datetime
import sh
import sys
import math
import sqlite3
from os import path

CAMERA_ON = True


def addCollectNumber(bf):
    #dirNum = 0
    #while True:
    #    testDir = bf + '/' + str(dirNum)
    #    if not path.isdir(testDir):
    #        return testDir + '/' + batchval
    #        break
    #    dirNum += 1
    with open('/home/pi/.boottime') as F:
        return bf + '/' + F.read().strip()


# Setup Output
if len(sys.argv) > 1:
    uploadFolder = sys.argv[1]
batchval = str(int(time.time()*1000))
currentDate = datetime.datetime.now().strftime('%Y-%m-%d')
batchval = str(int(time.time()*1000))
devName = 'David_s1'
batchFolder = '/'.join(['/home/pi/raspberrypi_ir/output', devName, currentDate])#, batchval])
batchFolder = addCollectNumber(batchFolder) + '/' + batchval
irCapFolder = batchFolder + '/ircapture'
rgbCamFolder = batchFolder + '/cameraimages'
dbFile = batchFolder + '/'+ batchval + '.db'
eepromFile = batchFolder + '/eeprom.csv'
sh.mkdir('-p', batchFolder)
sh.mkdir('-p', irCapFolder)
sh.mkdir('-p', rgbCamFolder)



def twos_comp(val, bits):
    """compute the 2's compliment of int value val"""
    if (val & (1 << (bits - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
        val = val - (1 << bits)        # compute negative value
    return val                         # return positive value as is


GPIO.setmode(GPIO.BCM)
GPIO.setup(27,GPIO.OUT)

print datetime.datetime.now().time()
if CAMERA_ON: camera = PiCamera()

# read the whole EEPROM
pi = pigpio.pi()

handle = pi.i2c_open(1, 0x50)
(count, eepromBytes) = pi.i2c_zip(handle, [2, 4, 0x50, 7, 1, 0x00, 6, 0xFF, 0])
if count < 0: sys.exit(count)
pi.i2c_close(handle)

with open(eepromFile, 'w') as FILE:
    FILE.write(','.join([str(b) for b in eepromBytes]))
    
for iter in range(0,1):
    print iter

#### Init the gpio pins #####################################################         
    pi = pigpio.pi()

#### Init the IR Camera #####################################################
    ###### read the oscillator trim ############
    handle = pi.i2c_open(1, 0x50)
    osctrim = pi.i2c_read_byte_data(handle,0xF7)
    pi.i2c_close(handle)

    ###### write the oscillator trim ###########
    b0 = osctrim - 0xAA
    if b0 < 0: b0 += 256
    b2 = 0x00 - 0xAA + 256

    handle = pi.i2c_open(1, 0x60)
    result = pi.i2c_write_i2c_block_data(handle,0x04,[b0,osctrim,b2,0x00])
    pi.i2c_close(handle)
    
    ###### read the oscillator trim ############
    # But, why?
    handle = pi.i2c_open(1, 0x60)
    # [combined, address:, 0x60, sending, 0x04 bytes, 0x02 (command, read?), 0x93 (start address),
    # 0x00 (address step), 0x01 (number of reads), receiving, 0x02 bytes, end]
    (count, byteArray)   = pi.i2c_zip(handle,[0x02, 0x04, 0x60, 0x07, 0x04, 0x02, 0x93, 0x00, 0x01, 0x06, 0x02, 0])
    if count < 0: sys.exit(count)
    pi.i2c_close(handle)

#### Configure the IR Camera ################################################

    refreshRate = 8   # <<-- THIS IS A CONFIGURATION SETTING. I'm not 100% clear on what it means. 8Hz? - David
    
    if refreshRate == 0:
        configLSB = 0b00111111
        confReg54 =    0b11
    elif refreshRate == 1:
        configLSB = 0b00111110
        confReg54 =    0b11
    elif refreshRate == 2:
        configLSB = 0b00111101
        confReg54 =    0b11
    elif refreshRate == 4:
        configLSB = 0b00111100
        confReg54 =    0b11
    elif refreshRate == 8:
        configLSB = 0b00111011
        confReg54 =    0b11
    elif refreshRate == 16:
        configLSB = 0b00111010
        confReg54 =    0b11
    elif refreshRate == 32:
        configLSB = 0b00111001
        confReg54 =    0b11
    else:
        configLSB = 0b00111110
        confReg54 =    0b11

    b0 = configLSB - 0x55
    if b0 < 0: b0 += 256
    
    configMSB = 0b01000110  # <<-- THIS IS A CONFIGURATION SETTING. I don't know what it does. - David

    b2 = configMSB - 0x55
    if b2 < 0: b2 += 256

    handle = pi.i2c_open(1, 0x60)
    result = pi.i2c_write_i2c_block_data(handle,0x03,[b0,configLSB,b2,configMSB])
    pi.i2c_close(handle)

    ###### Read the configuration ##########
    # Again, why? Was this just unremoved debug code?
    handle = pi.i2c_open(1, 0x60)
    # read, start at 0x92, step 0, 1 read, returns 2 bytes
    (count,byteArray)    = pi.i2c_zip(handle,[0x02, 0x04, 0x60, 0x07, 0x04, 0x02, 0x92, 0x00, 0x01, 0x06, 0x02, 0])
    if count < 0: sys.exit(count)
    pi.i2c_close(handle)
    Vth = twos_comp((eepromBytes[0xDB] << 8) + eepromBytes[0xDA], 16)
    Vth = float(Vth) / (2 ** (3 - confReg54))

#### Get the data IR Data ##################################################
    handle = pi.i2c_open(1, 0x60)
    # read, start at 0x00, step 1, 64 reads, returns 128 bytes
    (count, irbyteArray) = pi.i2c_zip(handle,[0x02, 0x04, 0x60, 0x07, 0x04, 0x02, 0x00, 0x01, 0x40, 0x06, 0x80, 0])
    if count < 0: sys.exit(count)    
    # read, start at 0x40, step 0, 1 read, returns 2 bytes
    (count, ptat_a)      = pi.i2c_zip(handle,[0x02, 0x04, 0x60, 0x07, 0x04, 0x02, 0x40, 0x00, 0x01, 0x06, 0x02, 0])
    if count < 0: sys.exit(count)
    # read, start at 0x41, step 0, 1 read, returns 2 bytes
    (count, comp_pix_a)  = pi.i2c_zip(handle,[0x02, 0x04, 0x60, 0x07, 0x04, 0x02, 0x41, 0x00, 0x01, 0x06, 0x02, 0])
    if count < 0: sys.exit(count)
    pi.i2c_close(handle)

    ###### Convert IR data to raw vals ########
    irData = []
    for i in range(0,len(irbyteArray)-1,2):
        low = irbyteArray[i] # get lsb
        high = irbyteArray[i+1] # get msb
        irData.append(twos_comp((high << 8) + low, 16))

    ###### Calculate ptat value ###############
    ptat = (ptat_a[1] << 8) + ptat_a[0]
    irData.append(ptat)

    ###### Calculate comp pixel value #########
    comp_pix = twos_comp((comp_pix_a[1] << 8) + comp_pix_a[0], 16)
    irData.append(comp_pix)

#### Write output ###########################################################
    ###### Make the file number ################
    fnumber = str(iter)
    if iter < 100: 
        fnumber = '0' + fnumber
        if iter < 10:
            fnumber = '0' + fnumber

    ###### Capture RGB ########################
    if CAMERA_ON:
        rgbname = rgbCamFolder + '/pic' + fnumber + '.jpg'
        camera.capture(rgbname)
        time.sleep(2)

    ###### Write IR data ######################
    filename = irCapFolder + '/pic' + fnumber + '.txt'    
    #f = open(filename,'w+')
    textData = [str(dat) for dat in irData]
    with open(filename, 'a') as FILE:
        FILE.write(','.join(textData))

#### Finish Up #############################################################
print datetime.datetime.now().time()

