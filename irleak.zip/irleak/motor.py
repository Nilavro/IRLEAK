import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setup(27,GPIO.OUT)

for i in range(0,100):
	GPIO.output(27,GPIO.LOW)
	print "HIGH"
	time.sleep(1)
	GPIO.output(27,GPIO.HIGH)
	print "LOW"
	time.sleep(1)
