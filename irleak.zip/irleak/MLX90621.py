import smbus

bus = smbus.SMBus(1)

#get trim value from eeprom
trim = bus.read_byte_data(0x50,0xF7)
#write trim value
result = bus.write_i2c_block_data(0x60,0x04,[trim-0xAA,trim,0x00-0xAA,0x00])


#configuration
#result = bus.write_i2c_block_data(0x60,0x03,[0xe9,0x3e,0xf1,0x46])
result = bus.write_i2c_block_data(0x60,0x03,[0x3e-0x55,0x3e,0x46-0x55,0x46])



#read configuration
         bus.write_i2c_block_data(0x60,0x02,[0x92,0x00,0x01])
result = bus.read_i2c_block_data(0x60,2)



#  
#/*
# * MLX90621.cpp
# *
# *  Created on: 18.11.2013
# *      Author: Max
# *
# *  Adapted by https://github.com/longjos
# *  	Adapted for use with Arduino UNO
# */
##include "MLX90621.h"
#

bus = smbus.SMBus(1)


#//Config register = 0xF5-F6
OSC_TRIM_VALUE=0xF7

#//Poll the MLX90621 for its current status
#//Returns true if the POR/Brown out bit is set
def checkConfig():
    check =  (((readConfig() & 0x0400) >> 10)==0)
    return check


def initialise(refrate=0):
  refreshRate = refrate;
  #delay(5);
  eeprom = readEEPROM();
  writeTrimmingValue();
  setConfiguration(refreshrate);
  #preCalculateConstants();
  return eeprom


def readConfig():
  bus.write_i2c_block_data(0x60,0x02,[0x92,0x00,0x01])
  
  data = bus.read_i2c_block_data(0x60,0)
  configLow = data[0];
  configHigh = data[1];    
  config = configHigh * 256 + configLow;
  return config;


#void MLX90621::measure(bool calculate_temps) {
#  if (checkConfig()) {
#      readEEPROM();
#      writeTrimmingValue();
#      setConfiguration();
#  }
#  readPTAT();
#  readIR();
#  if(calculate_temps){
#      calculateTA();
#      readCPIX();
#      calculateTO();
#  }
#  
#}


#float MLX90621::getTemperature(int num) {
#	if ((num >= 0) && (num < 64)) {
#		return temperatures[num];
#	} else {
#		return 0;
#	}
#}
#
#float MLX90621::getAmbient() {
#	return Tambient;
#}
#

def setConfiguration(refreshRate=0):

  if refereshRate == 0:
    Hz_LSB=0b00111111
  elif refereshRate == 1:
    Hz_LSB=0b00111110
  elif refereshRate == 2:
    Hz_LSB=0b00111101 
  elif refereshRate == 4:
    Hz_LSB=0b00111100
  elif refereshRate == 8:
    Hz_LSB=0b00111011
  elif refereshRate == 16:
    Hz_LSB=0b00111010
  elif refereshRate == 32:
    Hz_LSB=0b00111001
  else:
    Hz_LSB = 0b00111110;
  defaultConfig_H = 0b01000110;  #kmoto: See data sheet p.11 and 25
  bus.write_i2c_block_data(0x60,0x03,[Hz_LSB-0x55,Hz_LSB,defaultConfig_H-0x55,defaultConfig_H]);
  resolution = (readConfig() & 0x30) / 16;
  return resolution
  

def readEEPROM():
  #{ // Read in blocks of 32 bytes to accomodate Wire library
  eeprom = []
  for j in range(0,256,32):
    print j
    #bus.write_i2c_block_data(0x50,0,[j]);  
    bus.write_byte_data(0x50,0,j);
    eeprom.append(bus.read_i2c_block_data(0x60,0))
  return eeprom

def readIR():
  im = []
  for j in range(0,64,16):
    bus.write_i2c_block_data(0x60,0,[0x02,j,0x01,0x20])
    data8 = bus.read_i2c_block_data(0x60,0)
    for i in range(16):
      im.append(twos_16(data8[i+1]),data8[i])



def writeTrimmingValue(eepromData):
  bus.write_i2c_block_data(0x60,0,[eepromData[OSC_TRIM_VALUE] - 0xAA,eepromData[OSC_TRIM_VALUE],0x56,0x00])

  

#void MLX90621::calculateTA(void) {
#	Tambient = ((-k_t1 + sqrt(sq(k_t1) - (4 * k_t2 * (v_th - (float) ptat))))
#			/ (2 * k_t2)) + 25.0;
#}
#
#void MLX90621::preCalculateConstants() {
#	resolution_comp = pow(2.0, (3 - resolution));
#	emissivity = unsigned_16(eepromData[CAL_EMIS_H], eepromData[CAL_EMIS_L]) / 32768.0;
#	a_common = twos_16(eepromData[CAL_ACOMMON_H], eepromData[CAL_ACOMMON_L]);
#	a_i_scale = (int16_t)(eepromData[CAL_AI_SCALE] & 0xF0) >> 4;
#	b_i_scale = (int16_t) eepromData[CAL_BI_SCALE] & 0x0F;
#
#	alpha_cp = unsigned_16(eepromData[CAL_alphaCP_H], eepromData[CAL_alphaCP_L]) /
#			   (pow(2.0, eepromData[CAL_A0_SCALE]) * resolution_comp);
#	a_cp = (float) twos_16(eepromData[CAL_ACP_H], eepromData[CAL_ACP_L]) / resolution_comp;
#	b_cp = (float) twos_8(eepromData[CAL_BCP]) / (pow(2.0, (float)b_i_scale) * resolution_comp);
#	tgc = (float) twos_8(eepromData[CAL_TGC]) / 32.0;
#
#	k_t1_scale = (int16_t) (eepromData[KT_SCALE] & 0xF0) >> 4;
#	k_t2_scale = (int16_t) (eepromData[KT_SCALE] & 0x0F) + 10;
#	v_th = (float) twos_16(eepromData[VTH_H], eepromData[VTH_L]);
#	v_th = v_th / resolution_comp;
#	k_t1 = (float) twos_16(eepromData[KT1_H], eepromData[KT1_L]);
#	k_t1 /= (pow(2, k_t1_scale) * resolution_comp);
#	k_t2 = (float) twos_16(eepromData[KT2_H], eepromData[KT2_L]);
#	k_t2 /= (pow(2, k_t2_scale) * resolution_comp);
#}
#
#void MLX90621::calculateTO() {
#	float v_cp_off_comp = (float) cpix - (a_cp + b_cp * (Tambient - 25.0));
#	tak4 = pow((float) Tambient + 273.15, 4.0);
#	minTemp = NULL, maxTemp = NULL;
#	for (int i = 0; i < 64; i++) {
#		a_ij = ((float) a_common + eepromData[i] * pow(2.0, a_i_scale)) / resolution_comp;
#		b_ij = (float) twos_8(eepromData[0x40 + i]) / (pow(2.0, b_i_scale) * resolution_comp);
#		v_ir_off_comp = (float) irData[i] - (a_ij + b_ij * (Tambient - 25.0));
#		v_ir_tgc_comp = (float) v_ir_off_comp - tgc * v_cp_off_comp;
#		float alpha_ij = ((float) unsigned_16(eepromData[CAL_A0_H], eepromData[CAL_A0_L]) / pow(2.0, (float) eepromData[CAL_A0_SCALE]));
#		alpha_ij += ((float) eepromData[0x80 + i] / pow(2.0, (float) eepromData[CAL_DELTA_A_SCALE]));
#		alpha_ij = alpha_ij / resolution_comp;
#		//ksta = (float) twos_16(eepromData[CAL_KSTA_H], eepromData[CAL_KSTA_L]) / pow(2.0, 20.0);
#		//alpha_comp = (1 + ksta * (Tambient - 25.0)) * (alpha_ij - tgc * alpha_cp);
#		alpha_comp = (alpha_ij - tgc * alpha_cp);  	// For my MLX90621 the ksta calibrations were 0
#													// so I can ignore them and save a few cycles
#		v_ir_comp = v_ir_tgc_comp / emissivity;
#		float temperature = pow((v_ir_comp / alpha_comp) + tak4, 1.0 / 4.0) - 274.15;
#
#		temperatures[i] = temperature;
#		if (minTemp == NULL || temperature < minTemp) {
#			minTemp = temperature;
#		}
#		if (maxTemp == NULL || temperature > maxTemp) {
#			maxTemp = temperature;
#		}
#	}
#}
#
#float MLX90621::getMinTemp() {
#	return minTemp;
#}
#
#float MLX90621::getMaxTemp() {
#	return maxTemp;
#}
#







#    
#void MLX90621::readPTAT() {
#	Wire.beginTransmission(0x60);
#	Wire.write(0x02);
#	Wire.write(0x40);
#	Wire.write(0x00);
#	Wire.write(0x01);
#	Wire.endTransmission(false);
#	Wire.requestFrom(0x60, 2);
#	byte ptatLow = Wire.read();
#	byte ptatHigh = Wire.read();
#	ptat = (ptatHigh * 256) + ptatLow;
#
#}
#



############void MLX90621::readCPIX() {
############	Wire.beginTransmission(0x60);
############	Wire.write(0x02);
############	Wire.write(0x41);
############	Wire.write(0x00);
############	Wire.write(0x01);
############	Wire.endTransmission(false);
############	Wire.requestFrom(0x60, 2);
############	byte cpixLow = Wire.read();
############	byte cpixHigh = Wire.read();
############	cpix = twos_16(cpixHigh, cpixLow);
############}



def twos_16(highByte, lowByte):
	combined_word = 256 * highByte + lowByte;
	if (combined_word > 32767):
		return (combined_word - 65536);
	return combined_word;

###@#########int8_t MLX90621::twos_8(uint8_t byte) {
###@#########	if (byte > 127)
###@#########		return (int8_t) byte - 256;
###@#########	return (int8_t) byte;
###@#########}
###@#########
###@#########uint16_t MLX90621::unsigned_16(uint8_t highByte, uint8_t lowByte){
###@#########	return (highByte << 8) | lowByte;
###@#########}
###@#########




eeprom = initialise(refrate=0)
print eeprom


