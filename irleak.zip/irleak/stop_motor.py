#!/usr/bin/env python3

import RPi.GPIO as GPIO

if __name__ == '__main__':
  GPIO.setmode(GPIO.BCM)
  GPIO.setup(27,GPIO.OUT)
  GPIO.output(27,GPIO.HIGH)
