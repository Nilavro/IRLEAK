#!/usr/bin/env python
import smbus
import time
import pigpio
from picamera import PiCamera
import RPi.GPIO as GPIO
import datetime
import sh
import sys
import math
import sqlite3

CAMERA_ON = True

# Setup Output
if len(sys.argv) > 1:
    uploadFolder = sys.argv[1]
batchval = str(int(time.time()*1000))
batchFolder = '/home/pi/raspberrypi_ir/output/02-' + batchval
irCapFolder = batchFolder + '/ircapture'
rgbCamFolder = batchFolder + '/cameraimages'
dbFile = batchFolder + '/'+ batchval + '.db'
eepromFile = batchFolder + '/eeprom.csv'
sh.mkdir('-p', batchFolder)
sh.mkdir('-p', irCapFolder)
sh.mkdir('-p', rgbCamFolder)

def twos_comp(val, bits):
    """compute the 2's compliment of int value val"""
    if (val & (1 << (bits - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
        val = val - (1 << bits)        # compute negative value
    return val                         # return positive value as is


GPIO.setmode(GPIO.BCM)
GPIO.setup(27,GPIO.OUT)

print datetime.datetime.now().time()
if CAMERA_ON: camera = PiCamera()

# read the whole EEPROM
pi = pigpio.pi()

handle = pi.i2c_open(1, 0x50)
(count, eepromBytes) = pi.i2c_zip(handle, [2, 4, 0x50, 7, 1, 0x00, 6, 0xFF, 0])
if count < 0: sys.exit(count)
pi.i2c_close(handle)

with open(eepromFile, 'w') as FILE:
    FILE.write(','.join([str(b) for b in eepromBytes]))
    FILE.write('\n')
#with sqlite3.connect(dbFile) as CONN:
#    cur = CONN.cursor()
#    cur.execute('''create table if not exists EEPROM (NAME text primary key, VAL blob)''')
#    #cur.execute('''insert into EEPROM (NAME,VAL) values ('RAW',?)''', (eepromBytes,))
#    cur.execute('''create table if not exists IRDATA 
#(ITERATION integer primary key asc autoincrement, 
#    VAL000 real, VAL001 real, VAL002 real, VAL003 real,
#    VAL010 real, VAL011 real, VAL012 real, VAL013 real,
#    VAL020 real, VAL021 real, VAL022 real, VAL023 real,
#    VAL030 real, VAL031 real, VAL032 real, VAL033 real,
#    VAL040 real, VAL041 real, VAL042 real, VAL043 real,
#    VAL050 real, VAL051 real, VAL052 real, VAL053 real,
#    VAL060 real, VAL061 real, VAL062 real, VAL063 real,
#    VAL070 real, VAL071 real, VAL072 real, VAL073 real,
#    VAL080 real, VAL081 real, VAL082 real, VAL083 real,
#    VAL090 real, VAL091 real, VAL092 real, VAL093 real,
#    VAL100 real, VAL101 real, VAL102 real, VAL103 real,
#    VAL110 real, VAL111 real, VAL112 real, VAL113 real,
#    VAL120 real, VAL121 real, VAL122 real, VAL123 real,
#    VAL130 real, VAL131 real, VAL132 real, VAL133 real,
#    VAL140 real, VAL141 real, VAL142 real, VAL143 real,
#    VAL150 real, VAL151 real, VAL152 real, VAL153 real)''')

    
for iter in range(0,120):
    print iter

#### Init the gpio pins #####################################################         
    pi = pigpio.pi()

#### Init the IR Camera #####################################################
    ###### read the oscillator trim ############
    handle = pi.i2c_open(1, 0x50)
    osctrim = pi.i2c_read_byte_data(handle,0xF7)
    pi.i2c_close(handle)

    ###### write the oscillator trim ###########
    b0 = osctrim - 0xAA
    if b0 < 0: b0 += 256
    b2 = 0x00 - 0xAA + 256

    handle = pi.i2c_open(1, 0x60)
    result = pi.i2c_write_i2c_block_data(handle,0x04,[b0,osctrim,b2,0x00])
    pi.i2c_close(handle)
    
    ###### read the oscillator trim ############
    # But, why?
    handle = pi.i2c_open(1, 0x60)
    # [combined, address:, 0x60, sending, 0x04 bytes, 0x02 (command, read?), 0x93 (start address),
    # 0x00 (address step), 0x01 (number of reads), receiving, 0x02 bytes, end]
    (count, byteArray)   = pi.i2c_zip(handle,[0x02, 0x04, 0x60, 0x07, 0x04, 0x02, 0x93, 0x00, 0x01, 0x06, 0x02, 0])
    if count < 0: sys.exit(count)
    pi.i2c_close(handle)

#### Configure the IR Camera ################################################

    refreshRate = 8   # <<-- THIS IS A CONFIGURATION SETTING. I'm not 100% clear on what it means. 8Hz? - David
    
    if refreshRate == 0:
        configLSB = 0b00111111
        confReg54 =    0b11
    elif refreshRate == 1:
        configLSB = 0b00111110
        confReg54 =    0b11
    elif refreshRate == 2:
        configLSB = 0b00111101
        confReg54 =    0b11
    elif refreshRate == 4:
        configLSB = 0b00111100
        confReg54 =    0b11
    elif refreshRate == 8:
        configLSB = 0b00111011
        confReg54 =    0b11
    elif refreshRate == 16:
        configLSB = 0b00111010
        confReg54 =    0b11
    elif refreshRate == 32:
        configLSB = 0b00111001
        confReg54 =    0b11
    else:
        configLSB = 0b00111110
        confReg54 =    0b11

    b0 = configLSB - 0x55
    if b0 < 0: b0 += 256
    
    configMSB = 0b01000110  # <<-- THIS IS A CONFIGURATION SETTING. I don't know what it does. - David

    b2 = configMSB - 0x55
    if b2 < 0: b2 += 256

    handle = pi.i2c_open(1, 0x60)
    result = pi.i2c_write_i2c_block_data(handle,0x03,[b0,configLSB,b2,configMSB])
    pi.i2c_close(handle)

    ###### Read the configuration ##########
    # Again, why? Was this just unremoved debug code?
    handle = pi.i2c_open(1, 0x60)
    # read, start at 0x92, step 0, 1 read, returns 2 bytes
    (count,byteArray)    = pi.i2c_zip(handle,[0x02, 0x04, 0x60, 0x07, 0x04, 0x02, 0x92, 0x00, 0x01, 0x06, 0x02, 0])
    if count < 0: sys.exit(count)
    pi.i2c_close(handle)
    Vth = twos_comp((eepromBytes[0xDB] << 8) + eepromBytes[0xDA], 16)
    Vth = float(Vth) / (2 ** (3 - confReg54))

#### Get the data IR Data ##################################################
    handle = pi.i2c_open(1, 0x60)
    # read, start at 0x00, step 1, 64 reads, returns 128 bytes
    (count, irbyteArray) = pi.i2c_zip(handle,[0x02, 0x04, 0x60, 0x07, 0x04, 0x02, 0x00, 0x01, 0x40, 0x06, 0x80, 0])
    if count < 0: sys.exit(count)    
    # read, start at 0x40, step 0, 1 read, returns 2 bytes
    (count, ptat_a)      = pi.i2c_zip(handle,[0x02, 0x04, 0x60, 0x07, 0x04, 0x02, 0x40, 0x00, 0x01, 0x06, 0x02, 0])
    if count < 0: sys.exit(count)
    # read, start at 0x41, step 0, 1 read, returns 2 bytes
    (count, comp_pix_a)  = pi.i2c_zip(handle,[0x02, 0x04, 0x60, 0x07, 0x04, 0x02, 0x41, 0x00, 0x01, 0x06, 0x02, 0])
    if count < 0: sys.exit(count)
    pi.i2c_close(handle)

    ###### Convert IR data to raw vals ########
    irData = []
    for i in range(0,len(irbyteArray)-1,2):
        low = irbyteArray[i] # get lsb
        high = irbyteArray[i+1] # get msb
        #num = 256*high + low # combine bytes
        #irData.append(twos_comp(num,16)) # get two's complement of bytes
        irData.append(twos_comp((high << 8) + low, 16))

    ###### Calculate ptat value ###############
    ptat = (ptat_a[1] << 8) + ptat_a[0]
    irData.append(ptat)
    #print 'ptat', ptat

    ###### Calculate comp pixel value #########
    comp_pix = twos_comp((comp_pix_a[1] << 8) + comp_pix_a[0], 16)
    irData.append(comp_pix)
    #print 'comp_pix', comp_pix

    ###### Convert the EEPROM data numbers ####
#    Kt_scale = eepromBytes[0xD2]
#    Kt1_scale = (Kt_scale & 0xF0) >> 4
#    Kt2_scale = Kt_scale & 0x0F
    
#    Kt1 = twos_comp((eepromBytes[0xDD] << 8) + eepromBytes[0xDC], 16)
#    Kt1 = float(Kt1) / ((2 ** Kt1_scale) * (2 ** (3 - confReg54)))
    
#    Kt2 = twos_comp((eepromBytes[0xDF] << 8) + eepromBytes[0xDE], 16)
#    Kt2 = float(Kt2) / ((2 ** (Kt2_scale + 10)) * (2 ** (3 - confReg54)))
    
#    KsTa = twos_comp((eepromBytes[0xE7] << 8) + eepromBytes[0xE6], 16)
#    KsTa = float(KsTa) / (2 ** 20)
    
#    TGC = twos_comp(eepromBytes[0xD8], 8)
    
#    a0_scale = eepromBytes[0xE2]
#    delta_a_scale = eepromBytes[0xE3]
#    delta_A = [uint for uint in eepromBytes[0x00:0x40]]
#    Bi = [twos_comp(i,8) for i in eepromBytes[0x40:0x80]]
#    delta_a = [uint for uint in eepromBytes[0x80:0xC0]]
    
#    acp = twos_comp((eepromBytes[0xD4] << 8) + eepromBytes[0xD3], 16)
#    acp = float(acp) / ((2 ** a0_scale) * (2 ** (3 - confReg54)))

    
#### Compute Derived Values #################################################
    ###### Compute ambient pkg temp (Ta) #######
#    Ta = ((-Kt1 + (((Kt1 **2) - (4 * Kt2 * (Vth - ptat))) ** 0.5)) / (2 * Kt2)) + 25
#    print 'Ta', Ta
#    Tak4 = (Ta + 273.15) ** 4
    ###### Compute Compensated IR Signals ######
#    Vir_comp = []

    ###### Compute Compens Sensitivity Coeffs ##
#    coeff = 1 + (KsTa * (Ta - 25))
#    a_comp = []

    ######
#    To = [(((Vir_comp[i] / a_comp[i]) + Tak4) ** 0.25) - 273.15 for i,_ in enumerate(Vir_comp)]
    
#### Write output ###########################################################
    ###### Make the file number ################
    fnumber = str(iter)
    if iter < 100: 
        fnumber = '0' + fnumber
        if iter < 10:
            fnumber = '0' + fnumber

    ###### Capture RGB ########################
    if CAMERA_ON:
        rgbname = rgbCamFolder + '/pic' + fnumber + '.jpg'
        camera.capture(rgbname)
        time.sleep(2)

    ###### Write IR data ######################
    filename = irCapFolder + '/pic' + fnumber + '.txt'    
    #f = open(filename,'w+')
    textData = [str(dat) for dat in irData]
    with open(filename, 'a') as FILE:
        FILE.write(','.join(textData))
    #f.close()
#    realData = [float(dat) for dat in irData]
#    with sqlite3.connect(dbFile) as CONN:
#        cur = CONN.cursor()
#        cur.execute('''
#    insert into IRDATA 
#    (VAL000, VAL001, VAL002, VAL003,
#     VAL010, VAL011, VAL012, VAL013,
#     VAL020, VAL021, VAL022, VAL023,
#     VAL030, VAL031, VAL032, VAL033,
#     VAL040, VAL041, VAL042, VAL043,
#     VAL050, VAL051, VAL052, VAL053,
#     VAL060, VAL061, VAL062, VAL063,
#     VAL070, VAL071, VAL072, VAL073,
#     VAL080, VAL081, VAL082, VAL083,
#     VAL090, VAL091, VAL092, VAL093,
#     VAL100, VAL101, VAL102, VAL103,
#     VAL110, VAL111, VAL112, VAL113,
#     VAL120, VAL121, VAL122, VAL123,
#     VAL130, VAL131, VAL132, VAL133,
#     VAL140, VAL141, VAL142, VAL143,
#     VAL150, VAL151, VAL152, VAL153)
#    values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
#    realData)

#### Rotate Module #########################################################
    GPIO.output(27,GPIO.LOW)
    time.sleep(.025)
    GPIO.output(27,GPIO.HIGH)

#### Finish Up #############################################################
#sh.rsync('-azhe ssh /home/pi/raspberrypi_ir/output/ david@eclipse.umbc.edu:/tank/users/david/IRLeakData')
print datetime.datetime.now().time()

