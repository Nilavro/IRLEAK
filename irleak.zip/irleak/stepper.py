#!/usr/bin/env python3

import time
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
pins = {'b':22, 'p':23, 'y':24, 'o':25}
for p in pins.values(): GPIO.setup(p,GPIO.OUT)

{n: GPIO.input(p) for n,p in pins.items()}


def stater():
    i = 0
    s = [(1,0,1,0), (0,1,1,0), (0,1,0,1), (1,0,0,1)]
    while True:
        yield(s[i])
        i += 1
        i %= len(s)

def set_pins(ps, setting):
    GPIO.output(ps['p'], setting[0])
    GPIO.output(ps['o'], setting[1])
    GPIO.output(ps['y'], setting[2])
    GPIO.output(ps['b'], setting[3])

def forward():
    set_pins(pins, (1,0,1,0))
    time.sleep(.2)
    set_pins(pins, (0,1,1,0))
    time.sleep(.2)
    set_pins(pins, (0,1,0,1))
    time.sleep(.2)
    set_pins(pins, (1,0,0,1))
    time.sleep(.2)

def step(state):
    set_pins(pins, next(state))
    time.sleep(.125)

if __name__=='__main__':
    state = stater()
    for i in range(514):
        step(state)

