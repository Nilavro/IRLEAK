#!/usr/bin/env dash
rsync --remove-source-files -azhe ssh /home/pi/raspberrypi_ir/output/ david@eclipse.umbc.edu:/tank/usersc/david/IRLeakData
