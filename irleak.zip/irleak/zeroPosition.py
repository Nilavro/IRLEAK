#!/usr/bin/env python3

import time
import RPi.GPIO as GPIO


GPIO.setmode(GPIO.BCM)
pins = {'b':22, 'p':23, 'y':24, 'o':25}
GPIO.setup(8, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
for p in pins.values():
    GPIO.setup(p,GPIO.OUT)

def stater():
    i = 0
    s = [(1,0,1,0), (0,1,1,0), (0,1,0,1), (1,0,0,1)]
    while True:
        yield(s[i])
        i += 1
        i %= len(s)


def set_pins(ps, setting):
    GPIO.output(ps['p'], setting[0])
    GPIO.output(ps['o'], setting[1])
    GPIO.output(ps['y'], setting[2])
    GPIO.output(ps['b'], setting[3])


def step(state):
    set_pins(pins, next(state))
    time.sleep(.02)


def _main():
    st = stater()
    acc = 0
    prev = GPIO.input(8)
    if prev == 1:
        while GPIO.input(8) == 1:
            step(st)
            acc += 1
    while GPIO.input(8) == 0:
        step(st)
        acc += 1
    print(acc)


if __name__ == '__main__':
    _main()
    GPIO.cleanup()
